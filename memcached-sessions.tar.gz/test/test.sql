CREATE TABLE `session` (
  ses_id char(32) NOT NULL default '',
  user_id int(11) NOT NULL default '0',
  ses_time int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (ses_id)
) ENGINE=HEAP DEFAULT CHARSET=utf8;
