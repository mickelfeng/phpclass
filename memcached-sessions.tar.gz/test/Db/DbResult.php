<?php
class DbResult implements Iterator {
    private $result;

    private $rowsList = array();
    private $currentRow = 0;

    public function __construct(MySQLi_Result $result) {
        $this->result = $result;
    }
  
    public function numRows() {
        return $this->result->num_rows;
    }

    public function fetchOne($field = null) {
        $row = $this->result->fetch_assoc();

        if ($field === null) {
            return $row;
        } else {
            return isset($row[$field]) ? $row[$field] : null;
        }
    }

    public function fetchAll() {
        $rows = array();

        while (null !== ($row = $this->result->fetch_assoc())) {
            $rows[] = $row;
        }

        return $rows;
    }

	public function current() {
	   return $this->rowsList[$this->currentRow];
	}

	public function key() {
		return $this->currentRow;
	}

	public function next() {
        $this->appendRow(++$this->currentRow);

        return true;
	}


	public function prev() {
		--$this->currentRow;

		return true;
	}

	public function rewind() {
        $this->appendRow($this->currentRow = 0);

		return true;
	}

	public function valid() {
		return $this->rowsList[$this->currentRow] !== null;
	}

    private function appendRow($current_num) {
        if (!isset($this->rowsList[$current_num])) {
            $this->rowsList[$current_num] = $this->fetchOne();
        }
    }
}
?>
