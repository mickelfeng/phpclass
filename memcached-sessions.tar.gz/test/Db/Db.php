<?php
require_once dirname(__FILE__) . '/DbResult.php';
require_once dirname(__FILE__) . '/DbException.php';

class Db extends MySQLi {
    private $connectParams = array();
    private $debugMode     = false;
    private $debugInfo     = array();
    private $tablePrefix   = '';

    public function __construct($params) {
        $this->connectParams = $params;

        @parent::__construct(
            $this->connectParams['server'],
            $this->connectParams['user'],
            $this->connectParams['password'],
            $this->connectParams['database'],
            $this->connectParams['port']
        );

        if (mysqli_connect_errno()) {
            throw new DbConnectionException(mysqli_connect_error());
        }

        if (!empty($this->connectParams['charset'])) {
            $this->query('SET NAMES ?', $this->connectParams['charset']);
        }
    }

    public function setDebugMode($mode = true) {
        $this->debugMode = $mode;
    }

    public function getDebugInfo() {
        return $this->debugInfo;
    }

    public function setTablePrefix($prefix) {
        $this->tablePrefix = $prefix;
    }

    public function insertId() {
        return $this->insert_id;
    }

    public function affectedRows() {
        return $this->affected_rows;
    }

    public function query($query, $params = array()) {
        $query = $this->buildQuery($query, (array)$params);
        $start_time = microtime(true);

        if (!$result = parent::query($query)) {
            throw new DbQueryException('Error "' . $this->error . '" in query "' . trim($query) . '"');
        }

        $stop_time = microtime(true);

        if ($this->debugMode && !preg_match('/^\s*EXPLAIN/i', $query)) {
            $explain = array();

            if (preg_match('/^\s*SELECT/i', $query)) {
                try {
                    $explain = $this->query('EXPLAIN ' . $query)->fetchAll();
                } catch (DbQueryException $e) {}
            }

            $this->debugInfo[] = array(
                'query'   => $query,
                'time'    => number_format($stop_time - $start_time, 6),
                'explain' => $explain,
            );
        }

        return ($result instanceof MySQLi_Result) ? new DbResult($result) : $result;
    }

    private function buildQuery($query, $params = array()) {
        $query = str_replace('#__', $this->tablePrefix, $query);

        if ($params) {
            $query = str_replace(array('%', '?'), array('%%', '%s'), $query);
            $query = vsprintf($query, $this->prepareParams($params));
        }

        return $query;
    }

    private function prepareParams($params) {
        foreach ($params as &$param) {
            if (is_array($param)) {
                $param = $this->prepareParams($param);
            } else {
                $param = $this->escape($param);
            }
        }

        return $params;
    }

    public function escape($value) {
        if (is_numeric($value)) {
            return $value;
        } elseif (is_bool($value)) {
            return $value ? 1 : 0;
        } elseif (is_null($value)) {
            return 'NULL';
        }

        return "'" . $this->real_escape_string($value) . "'";
    }
}
?>
