<?php
class DbException extends Exception {
}

class DbConnectionException extends DbException {
}

class DbQueryException extends DbException {
}
?>
