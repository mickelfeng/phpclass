<?php
require_once dirname(__FILE__) . '/../SessionStorage.php';

class MemorySessionStorage implements SessionStorage {
    private $cache;
    private $expire;

    public function __construct(Cache $cache) {
        $this->cache = $cache;
    }

    public function open() {
        $this->expire = time() + (session_cache_expire() * 60);
    }

    public function close() {
    }

    public function read($session_id) {
        return $this->cache->get('session_' . $session_id);
    }

    public function write($session_id, $data) {
        return $this->cache->set(
            'session_' . $session_id, $data,
            array(
                'ttl' => $this->expire
            )
        );
    }

    public function destroy($session_id) {
        return $this->cache->remove('session_' . $session_id);
    }

    public function gc($max_life_time) {
        // Memcached make this itself
    }
}
?>
