<?php
interface SessionStorage {
    public function open();

    public function close();

    public function read($session_id);

    public function write($session_id, $data);

    public function destroy($session_id);

    public function gc($max_life_time);
}
?>
