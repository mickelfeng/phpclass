<?php
require_once dirname(__FILE__) . '/SessionStorage.php';
require_once dirname(__FILE__) . '/Storage/MemorySessionStorage.php';

class Session {
    private $storage;

    public function __construct(SessionStorage $storage) {
        $this->storage = $storage;

        session_set_save_handler(
            array($this->storage, 'open'),
            array($this->storage, 'close'),
            array($this->storage, 'read'),
            array($this->storage, 'write'),
            array($this->storage, 'destroy'),
            array($this->storage, 'gc')
        );
    }

    public function setStorage(SessionStorage $storage) {
        $this->storage = $storage;
    }

    public function getStorage() {
        return $this->storage;
    }

    public function start() {
        session_start();
    }

    public function set($key, $value) {
        $_SESSION[$key] = $value;
    }

    public function get($key, $default = null) {
        return isset($_SESSION[$key]) ? $_SESSION[$key] : $default;
    }

    public function has($key) {
        return isset($_SESSION[$key]);
    }

    public function remove($key) {
        unset($_SESSION[$key]);
    }

    public function clean() {
        $_SESSION = array();
    }
}
?>
