<?php
require_once './Session/Session.php';
require_once './Cache/Cache.php';
require_once './Db/Db.php';
require_once './Toolkit/Toolkit.php';

class MySessionStorage extends MemorySessionStorage {
    private $db;
    private $userId = 0;

    public function __construct() {
        parent::__construct(Toolkit::instance()->getCache());
        $this->db = Toolkit::instance()->getDb();
    }

    public function setUserId($id) {
        $this->userId = $id;
    }

    public function getUserId() {
        return $this->userId;
    }

    public function getOnlineCount() {
        $query = '
            SELECT COUNT(*) AS count
            FROM session
            WHERE ses_time > (UNIX_TIMESTAMP() - 300)
        ';

        return $this->db->query($query)->fetchOne('count');
    }

    public function read($session_id) {
        $query = '
            SELECT user_id FROM session WHERE ses_id = ?
        ';
        $this->userId = $this->db->query($query, $session_id)->fetchOne('user_id');

        return parent::read($session_id);
    }

    public function write($session_id, $data) {
        $query = '
            REPLACE INTO session (ses_id, user_id, ses_time) VALUES (?, ?, UNIX_TIMESTAMP())
        ';
        $this->db->query($query, array($session_id, $this->userId));

        return parent::write($session_id, $data);
    }
}

try {
    Toolkit::instance()->setDb(new Db(array('server' => 'localhost', 'user' => 'root', 'database' => 'test')));
    Toolkit::instance()->setCache(Cache::factory('memory'));

    $session = new Session(new MySessionStorage());
    $session->start();
    
    if (!$session->has('time')) {
        $session->set('time', time());
    }

    if (!$session->getStorage()->getUserId()) {
        $session->getStorage()->setUserId(321);
    }

    print 'Online: ' . $session->getStorage()->getOnlineCount();
} catch (Exception $e) {
    print $e->getMessage();
}
