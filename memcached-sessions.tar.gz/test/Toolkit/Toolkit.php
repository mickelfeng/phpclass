<?php
class Toolkit {
    private $cache;
    private $db;

    private static $instance;

    public static function instance() {
        if (!self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function setCache($cache) {
        $this->cache = $cache;
    }

    public function getCache() {
        return $this->cache;
    }

    public function setDb($db) {
        $this->db = $db;
    }

    public function getDb() {
        return $this->db;
    }
}
