<?php
require_once dirname(__FILE__) . '/CacheException.php';

/**
 * Cache core
 */ 
class Cache {
    private $backend;

    public static function factory($backend_type = 'file', $options = array()) {
        $class_name = ucfirst($backend_type) . 'CacheBackend';
        $filename = dirname(__FILE__) . '/Backend/' . basename($class_name) . '.php';

        if (!file_exists($filename)) {
            throw new CacheException(
                'File "' . $filename . '" for backend "' . $backend_type . '" not found.'
            );
        }

        require_once $filename;

        if (!class_exists($class_name)) {
            throw new CacheException(
                'Class "' . $class_name . '" for backend "' . $backend_type . '" not found.'
            );
        }

        return new self(new $class_name($options));
    }

    public function __construct(CacheBackend  $backend) {
        $this->backend = $backend;
    }

    public function setBackend(CacheBackend $backend) {
        $this->backend = $backend;
    }

    public function getBackend() {
        return $this->backend;
    }

    public function set($key, $value, $options = array()) {
        $this->backend->write($key, $value, $options);
    }

    public function get($key) {
        return $this->backend->read($key);
    }

    public function has($key) {
        return $this->get($key) !== null;
    }

    public function remove($key) {
        $this->backend->delete($key);
    }

    public function clean() {
        $this->backend->flush();
    }
}
