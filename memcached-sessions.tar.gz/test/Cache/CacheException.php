<?php
/**
 * Cache exception
 */
class CacheException extends Exception {
}
