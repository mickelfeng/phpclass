<?php
require_once dirname(__FILE__) . '/../CacheBackend.php';
require_once dirname(__FILE__) . '/../CacheException.php';

/**
 * Backend for memcached
 */ 
class MemoryCacheBackend extends CacheBackend {
    private $memcache;
    protected $options = array(
        'server'     => 'localhost',
        'port'       => 11211,
        'persistent' => false,
        'ttl'        => 0,
    );

    public function __construct(array $options = array()) {
        parent::__construct($options);

        $this->memcache = new MemCache();

        if (
            !$this->memcache->connect(
                $this->options['server'],
                $this->options['port']
            )
        ) {
            throw new CacheException(
                'Error connecting to memcached at ' .
                $this->options['server'] . ':' .$this->options['port']
            );
        }
    }

    public function write($key, $value, $options = array()) {
        if (!isset($options['ttl'])) {
            $options['ttl'] = $this->options['ttl'];
        }

        $this->memcache->set($key, $value, null, $this->getExpireByTtl($options['ttl']));
    }

    public function read($key) {
        $value = $this->memcache->get($key);

        return $value !== false ? $value : null;
    }

    public function delete($key) {
        $this->memcache->delete($key);
    }

    public function flush() {
        $this->memcache->flush();
    }
}
