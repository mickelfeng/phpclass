<?php
/**
 * Cache backend abstract
 */ 
abstract class CacheBackend {
    protected $options = array();

    public function __construct(array $options = array()) {
        $this->setOptions($options);
    }

    public abstract function write($key, $value, $options = array());

    public abstract function read($key);

    public abstract function delete($key);

    public abstract function flush();

    public function setOptions($options) {
        foreach ($options as $k => $v) {
            $this->options[$k] = $v;
        }
    }

    public function setOption($name, $value) {
        $this->options[$name] = $value;
    }

    public function getOption($name) {
        return isset($this->options[$name]) ? $this->options[$name] : null;
    }

    protected function getExpireByTtl($ttl) {
        if (is_string($ttl)) {
            return strtotime($ttl);
        } elseif ($ttl < (86400 * 30)) {
            return time() + $ttl;
        }

        return $ttl;
    }
}
