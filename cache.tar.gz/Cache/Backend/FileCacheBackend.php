<?php
/**
 * @link   http://sergey89.ru/
 * @author Sergey Fedotov <sergey89@gmail.com>
 */

require_once dirname(__FILE__) . '/../CacheBackendAbstract.php';
require_once dirname(__FILE__) . '/../CacheException.php';

/**
 * Backend for file system
 */ 
class FileCacheBackend extends CacheBackendAbstract {
    protected $options = array(
        'cache_dir'     => './cache',
        'max_life_time' => 2592000, // 1 Month
        'ttl'           => 0,
    );

    public function __construct(array $options = array()) {
        parent::__construct($options);
        
        if (!is_writeable($this->options['cache_dir'])) {
            if (!mkdir($this->options['cache_dir'], 0700, true)) {
                throw new CacheException(
                    'Directory "' .
                    $this->options['cache_dir'] .
                    '" is not writeable.'
                );
            }
        }
    }

    public function write($key, $value, $options = array()) {
        if (!isset($options['ttl'])) {
            $options['ttl'] = $this->options['ttl'];
        }

        if ($options['ttl'] == 0) {
            $options['ttl'] = $options['max_life_time'];
        }

        $filename = $this->getFileName($key);

        if (
            is_file($filename) &&
            !is_writeable($filename)
        ) {
            return false;
        }

        file_put_contents($filename, serialize($value));

        touch($filename, $this->getExpireByTtl($options['ttl']));
        clearstatcache();
    }

    public function read($key) {
        $filename = $this->getFileName($key);

        if (!is_readable($filename)) {
            return null;
        }

        if (filemtime($filename) < time()) {
            return null;
        }

        $data = file_get_contents($filename);

        return unserialize($data);
    }

    public function delete($key) {
        return unlink($this->getFileName($key));
    }

    public function flush() {
        foreach (glob($this->options['cache_dir'] . '/*') as $filename) {
            unlink($filename);
        }
    }

    private function getFileName($key) {
        return $this->options['cache_dir'] . '/' . md5($key);
    }
}
