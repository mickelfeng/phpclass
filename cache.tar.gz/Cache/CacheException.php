<?php
/**
 * @link   http://sergey89.ru/
 * @author Sergey Fedotov <sergey89@gmail.com>
 */

/**
 * Cache exception
 */
class CacheException extends Exception {
}
