/*
  +----------------------------------------------------------------------+
  | PHP Version 5                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 2010-2011 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.01 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_01.txt                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author: liexusong<liexusong@qq.com>                                  |
  +----------------------------------------------------------------------+
*/

/* $Id: header,v 1.16.2.1.2.1 2007/01/01 19:32:09 iliaa Exp $ */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "php.h"
#include "php_ini.h"
#include "ext/standard/info.h"
#include "php_dict.h"
#include "avl.h"

/* If you declare any globals in php_dict.h uncomment this:
ZEND_DECLARE_MODULE_GLOBALS(dict)
*/

/* True global resources - no need for thread safety here */
static int le_dict;
static zend_class_entry *dict_ce;

/* {{{ dict_functions[]
 *
 * Every user visible function must have an entry in dict_functions[].
 */

zend_function_entry dict_methods[] = {
	PHP_ME(dict, __construct,          NULL, ZEND_ACC_PUBLIC|ZEND_ACC_CTOR)
	PHP_ME(dict, insert,               NULL, ZEND_ACC_PUBLIC)
	PHP_ME(dict, find,                 NULL, ZEND_ACC_PUBLIC)
	PHP_ME(dict, find_min,             NULL, ZEND_ACC_PUBLIC)
	PHP_ME(dict, find_max,             NULL, ZEND_ACC_PUBLIC)
	PHP_ME(dict, remove,               NULL, ZEND_ACC_PUBLIC)
	{NULL, NULL, NULL}
};

/* }}} */

/* {{{ dict_module_entry
 */
zend_module_entry dict_module_entry = {
#if ZEND_MODULE_API_NO >= 20010901
	STANDARD_MODULE_HEADER,
#endif
	"dict",
	dict_methods,
	PHP_MINIT(dict),
	PHP_MSHUTDOWN(dict),
	PHP_RINIT(dict),		/* Replace with NULL if there's nothing to do at request start */
	PHP_RSHUTDOWN(dict),	/* Replace with NULL if there's nothing to do at request end */
	PHP_MINFO(dict),
#if ZEND_MODULE_API_NO >= 20010901
	"0.1", /* Replace with version number for your extension */
#endif
	STANDARD_MODULE_PROPERTIES
};
/* }}} */

#ifdef COMPILE_DL_DICT
ZEND_GET_MODULE(dict)
#endif

/* {{{ PHP_INI
 */
/* Remove comments and fill if you need to have entries in php.ini
PHP_INI_BEGIN()
    STD_PHP_INI_ENTRY("dict.global_value",      "42", PHP_INI_ALL, OnUpdateLong, global_value, zend_dict_globals, dict_globals)
    STD_PHP_INI_ENTRY("dict.global_string", "foobar", PHP_INI_ALL, OnUpdateString, global_string, zend_dict_globals, dict_globals)
PHP_INI_END()
*/
/* }}} */

/* {{{ php_dict_init_globals
 */
/* Uncomment this function if you have INI entries
static void php_dict_init_globals(zend_dict_globals *dict_globals)
{
	dict_globals->global_value = 0;
	dict_globals->global_string = NULL;
}
*/
/* }}} */

static void dict_destructor(zend_rsrc_list_entry * rsrc TSRMLS_DC)
{
    avl_tree_t *avl = (avl_tree_t *) rsrc->ptr;
    avl_destroy(avl);
}

/* {{{ PHP_MINIT_FUNCTION
 */
PHP_MINIT_FUNCTION(dict)
{
	zend_class_entry ce;
	
	INIT_CLASS_ENTRY(ce, "dict", dict_methods);
	dict_ce = zend_register_internal_class(&ce TSRMLS_CC);
	
	le_dict = zend_register_list_destructors_ex(
        dict_destructor,
        NULL,
        "dict class", module_number
    );

	REGISTER_LONG_CONSTANT("DICT_TYPE_STR", AVL_STR_TYPE, CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("DICT_TYPE_INT", AVL_INT_TYPE, CONST_CS | CONST_PERSISTENT);
	
	return SUCCESS;
}
/* }}} */

/* {{{ PHP_MSHUTDOWN_FUNCTION
 */
PHP_MSHUTDOWN_FUNCTION(dict)
{
	/* uncomment this line if you have INI entries
	UNREGISTER_INI_ENTRIES();
	*/
	return SUCCESS;
}
/* }}} */

/* Remove if there's nothing to do at request start */
/* {{{ PHP_RINIT_FUNCTION
 */
PHP_RINIT_FUNCTION(dict)
{
	return SUCCESS;
}
/* }}} */

/* Remove if there's nothing to do at request end */
/* {{{ PHP_RSHUTDOWN_FUNCTION
 */
PHP_RSHUTDOWN_FUNCTION(dict)
{
	return SUCCESS;
}
/* }}} */

/* {{{ PHP_MINFO_FUNCTION
 */

PHP_MINFO_FUNCTION(dict)
{
	php_info_print_table_start();
	php_info_print_table_header(2, "dict support", "enabled");
	php_info_print_table_end();

	/* Remove comments if you have entries in php.ini
	DISPLAY_INI_ENTRIES();
	*/
}
/* }}} */


/* Remove the following function when you have succesfully modified config.m4
   so that your module can be compiled into PHP, it exists only for testing
   purposes. */

/* Every user-visible function in PHP should document itself in the source */
/* {{{ */

int dict_get_resource(zval *id, avl_tree_t **avl TSRMLS_DC)
{

    zval **object;
    int resource_type;

    if (Z_TYPE_P(id) != IS_OBJECT || zend_hash_find(Z_OBJPROP_P(id), "dict_resource", 
        sizeof("dict_resource"), (void **) &object) == FAILURE) {
        return -1;
    }

    *avl = (avl_tree_t *) zend_list_find(Z_LVAL_PP(object), &resource_type);

    if (!*avl || resource_type != le_dict) {
        return -1;
    }

    return Z_LVAL_PP(object);
}

static int dict_str_compare(avl_key_t *key1, avl_key_t *key2) {
	char *str1 = (char *)key1;
	char *str2 = (char *)key2;
	return strcmp(str1, str2);
}

static int dict_int_compare(avl_key_t *key1, avl_key_t *key2) {
	int int1 = (int)key1;
	int int2 = (int)key2;
	return (int1 - int2);
}

ZEND_METHOD(dict, __construct)
{
	avl_tree_t *dict;
	zval *object;
	long type;
	int id;
	
	if (zend_parse_method_parameters(ZEND_NUM_ARGS() TSRMLS_CC, getThis(), "Ol",
           &object, dict_ce, &type) == FAILURE) {
       RETURN_FALSE;
    }
    
	dict = avl_alloc((type == AVL_STR_TYPE ? dict_str_compare : dict_int_compare), type);
	id = zend_list_insert(dict, le_dict);
    add_property_resource(object, "dict_resource", id);
}

ZEND_METHOD(dict, insert)
{
	zval *object;
	zval *key;
	zval *value;
	avl_tree_t *avl;
	void *keyptr;
	char buff[256];
	
	if (zend_parse_method_parameters(ZEND_NUM_ARGS() TSRMLS_CC, getThis(), "Ozz", &object, dict_ce, &key, &value) == FAILURE) {
       RETURN_FALSE;
    }
	
    if (dict_get_resource(object, &avl TSRMLS_CC) < 0) {
		RETURN_FALSE;
	}
	
	if (avl->type == AVL_STR_TYPE) { /* string type */
		if (Z_TYPE_P(key) == IS_STRING) {
			keyptr = (void *)Z_STRVAL_P(key);
		} else if (Z_TYPE_P(key) == IS_LONG) {
			keyptr = (void *)buff;
			sprintf(keyptr, "%ld", Z_LVAL_P(key));
		} else {
			RETURN_FALSE;
		}
	} else { /* int type */
		if (Z_TYPE_P(key) != IS_LONG) {
			RETURN_FALSE;
		}
		keyptr = (void *)Z_LVAL_P(key);
	}
	
	ZVAL_ADDREF(value);/* add refcount */
	if (avl_insert(avl, keyptr, value) == -1) {
		RETURN_FALSE;
	} else {
		RETURN_TRUE;
	}
}

ZEND_METHOD(dict, find)
{
	zval *object;
	zval *key;
	zval *value;
	avl_tree_t *avl;
	void *keyptr;
	char buff[256];
	
	if (zend_parse_method_parameters(ZEND_NUM_ARGS() TSRMLS_CC, getThis(), "Oz", &object, dict_ce, &key) == FAILURE) {
       RETURN_FALSE;
    }
	
    if (dict_get_resource(object, &avl TSRMLS_CC) < 0) {
		RETURN_FALSE;
	}
	
	if (avl->type == AVL_STR_TYPE) {
		if (Z_TYPE_P(key) == IS_STRING) {
			keyptr = (void *)Z_STRVAL_P(key);
		} else if (Z_TYPE_P(key) == IS_LONG) {
			keyptr = (void *)buff;
			sprintf(keyptr, "%ld", Z_LVAL_P(key));
		} else {
			RETURN_FALSE;
		}
	} else {
		if (Z_TYPE_P(key) != IS_LONG) {
			RETURN_FALSE;
		}
		keyptr = (void *)Z_LVAL_P(key);
	}
	
	value = avl_find(avl, keyptr);
	if (value) {
		RETURN_ZVAL(value, 1, 0);
	}
	RETURN_FALSE;
}

ZEND_METHOD(dict, find_min)
{
	zval *object;
	zval *value;
	avl_tree_t *avl;
	
	if (zend_parse_method_parameters(ZEND_NUM_ARGS() TSRMLS_CC, getThis(), "O", &object, dict_ce) == FAILURE) {
       RETURN_FALSE;
    }
	
    if (dict_get_resource(object, &avl TSRMLS_CC) < 0) {
		RETURN_FALSE;
	}
	
	value = avl_find_min(avl);
	if (value) {
		RETURN_ZVAL(value, 1, 0);
	}
	RETURN_FALSE;
}

ZEND_METHOD(dict, find_max)
{
	zval *object;
	zval *value;
	avl_tree_t *avl;
	
	if (zend_parse_method_parameters(ZEND_NUM_ARGS() TSRMLS_CC, getThis(), "O", &object, dict_ce) == FAILURE) {
       RETURN_FALSE;
    }
	
    if (dict_get_resource(object, &avl TSRMLS_CC) < 0) {
		RETURN_FALSE;
	}
	
	value = avl_find_max(avl);
	if (value) {
		RETURN_ZVAL(value, 1, 0);
	}
	RETURN_FALSE;
}

ZEND_METHOD(dict, remove)
{
	zval *object;
	zval *key;
	avl_tree_t *avl;
	void *keyptr;
	char buff[256];
	
	if (zend_parse_method_parameters(ZEND_NUM_ARGS() TSRMLS_CC, getThis(), "Oz", &object, dict_ce, &key) == FAILURE) {
       RETURN_FALSE;
    }
	
    if (dict_get_resource(object, &avl TSRMLS_CC) < 0) {
		RETURN_FALSE;
	}
	
	if (avl->type == AVL_STR_TYPE) {
		if (Z_TYPE_P(key) == IS_STRING) {
			keyptr = (void *)Z_STRVAL_P(key);
		} else if (Z_TYPE_P(key) == IS_LONG) {
			keyptr = (void *)buff;
			sprintf(keyptr, "%ld", Z_LVAL_P(key));
		} else {
			RETURN_FALSE;
		}
	} else {
		if (Z_TYPE_P(key) != IS_LONG) {
			RETURN_FALSE;
		}
		keyptr = (void *)Z_LVAL_P(key);
	}
	
	if (avl_remove(avl, keyptr) == -1) {
		RETURN_FALSE;
	}
	RETURN_TRUE;
}

/* The previous line is meant for vim and emacs, so it can correctly fold and 
   unfold functions in source code. See the corresponding marks just before 
   function definition, where the functions purpose is also documented. Please 
   follow this convention for the convenience of others editing your code.
*/


/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
