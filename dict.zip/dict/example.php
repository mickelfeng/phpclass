<?php
//DICT_TYPE_INT || DICT_TYPE_STR
$dict = new dict(DICT_TYPE_INT);

$start = microtime(TRUE);

for ($i = 0; $i < 1000000; $i++) {
	$dict->insert($i, "value_$i");
}

$end = microtime(TRUE);
echo $end - $start, "\n";

echo $dict->find($i), "\n";//found key

echo microtime(TRUE) - $end, "\n";

echo $dict->find_min(), "\n";//found the min

echo $dict->find_max();//found the max
?>