/*
  AVL Tree
  base on <Introduction to algorithm>
  (C) 2011 liexusong <liexusong@qq.com>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "avl.h"

#define THE_MAX_LEVEL 45 /* The max level for avl tree */

/* Some useful macros */
#define themax(v1, v2) ((v1) > (v2) ? (v1) : (v2))
#define heightof(node) ((node) == NULL ? 0 : (node)->height)

int avl_default_compare(avl_key_t val1, avl_key_t val2) {
	int e1 = (int)val1;
	int e2 = (int)val2;
	return (e1 - e2);
}

avl_tree_t *avl_alloc(avl_compare_t compare, int type)
{
	avl_tree_t *avl;
	
	avl = zmalloc(sizeof(avl_tree_t));
	if (avl) {
		avl->root = NULL;
		avl->size = 0;
		avl->type = type;
		avl->compare = compare;
	}
	
	return avl;
}

avl_tree_t *avl_alloc_default()
{
	return avl_alloc(avl_default_compare, AVL_INT_TYPE);
}

void *avl_find(avl_tree_t *avl, avl_key_t key)
{
	int comp_res;
	struct avl_node *node;
	
	node = avl->root;
	while (node) {
		comp_res = avl->compare(key, node->key);
		if (comp_res < 0) {
			node = node->left;
		} else if (comp_res > 0) {
			node = node->right;
		} else {
			return node->val;
		}
	}
	return NULL;
}

static void do_rebalance(struct avl_node ***stack_ptr, int count)
{
	for (; count > 0; count--) {
		struct avl_node **nodeplace = *--stack_ptr;
		struct avl_node *node = *nodeplace;
		struct avl_node *nodeleft = node->left;
		struct avl_node *noderight = node->right;
		int heightleft = heightof(nodeleft);
		int heightright = heightof(noderight);
		
		if (heightleft - heightright > 1)
		{
			struct avl_node *nodeleftleft = nodeleft->left;
			struct avl_node *nodeleftright = nodeleft->right;
			if (heightof(nodeleftleft) >= heightof(nodeleftright)) {//single right rorate
				node->left = nodeleft->right;
				nodeleft->right = node;
				node->height = themax(heightof(node->left), heightof(node->right)) + 1;
				nodeleft->height = themax(heightof(nodeleft->left), heightof(nodeleft->right)) + 1;
				*nodeplace = nodeleft;
			} else {//double left right rorate
				nodeleft->right = nodeleftright->left;
				node->left = nodeleftright->right;
				nodeleftright->left = nodeleft;
				nodeleftright->right = node;
				nodeleft->height = themax(heightof(nodeleft->left), heightof(nodeleft->right)) + 1;
				node->height = themax(heightof(node->left), heightof(node->right)) + 1;
				nodeleftright->height = themax(heightof(nodeleftright->left), heightof(nodeleftright->right)) + 1;
				*nodeplace = nodeleftright;
			}
		}
		else if (heightright - heightleft > 1)
		{
			struct avl_node *noderightleft = noderight->left;
			struct avl_node *noderightright = noderight->right;
			if (heightof(noderightright) >= heightof(noderightleft)) {
				node->right = noderight->left;
				noderight->left = node;
				node->height = themax(heightof(node->left), heightof(node->right)) + 1;
				noderight->height = themax(heightof(noderight->left), heightof(noderight->right)) + 1;
				*nodeplace = noderight;
			} else {
				noderight->left = noderightleft->right;
				node->right = noderightleft->left;
				noderightleft->left = node;
				noderightleft->right = noderight;
				node->height = themax(heightof(node->left), heightof(node->right)) + 1;
				noderight->height = themax(heightof(noderight->left), heightof(noderight->right)) + 1;
				noderightleft->height = themax(heightof(noderightleft->left), heightof(noderightleft->right)) + 1;
				*nodeplace = noderightleft;
			}
		}
		else
		{
			int height = themax(heightof(nodeleft), heightof(noderight)) + 1;
			if (height == node->height)
				break;
			node->height = height;
		}
	}
}

int avl_insert(avl_tree_t *avl, avl_key_t key, void *val)
{
	int res;
	struct avl_node **stack[THE_MAX_LEVEL];
	struct avl_node ***stack_ptr = &stack[0];
	int stack_count = 0;
	struct avl_node **nodeplace, *newnode;
	
	nodeplace = &(avl->root);
	for (;;) {
		if (!*nodeplace)
			break;
		*stack_ptr++ = nodeplace; stack_count++;
		res = avl->compare(key, (*nodeplace)->key);
		if (res < 0) {
			nodeplace = &(*nodeplace)->left;
		} else if (res > 0) {
			nodeplace = &(*nodeplace)->right;
		} else {
			return -1;
		}
	}
	
	newnode = zmalloc(sizeof(struct avl_node));
	if (!newnode)
		return -1;
	newnode->left = newnode->right = NULL;
	newnode->height = 1;
	if (avl->type == AVL_STR_TYPE) {
		int length = strlen(key);
		newnode->key = zmalloc(length+1);
		memcpy(newnode->key, key, length);
		*(((char *)newnode->key) + length) = '\0';
	} else {
		newnode->key = key;
	}
	newnode->val = val;
	*nodeplace = newnode;
	
	do_rebalance(stack_ptr, stack_count);
	avl->size++;
	return 0;
}

int avl_remove(avl_tree_t *avl, avl_key_t key)
{
	int res;
	struct avl_node **stack[THE_MAX_LEVEL];
	struct avl_node ***stack_ptr = &stack[0];
	int stack_count = 0;
	struct avl_node **nodeplace, **nodeplace_to_delete, *node, *node_to_delete;
	
	nodeplace = &(avl->root);
	for (;;) {
		node = *nodeplace;
		if (!node)
			return -1;
		*stack_ptr++ = nodeplace; stack_count++;
		res = avl->compare(key, node->key);
		if (res < 0) {
			nodeplace = &node->left;
		} else if (res > 0) {
			nodeplace = &node->right;
		} else {
			break;
		}
	}
	node_to_delete = *nodeplace;
	nodeplace_to_delete = nodeplace;
	
	if (!(*nodeplace)->left) {
		*nodeplace_to_delete = node_to_delete->right;
		stack_ptr--;
		stack_count--;
	} else {
		struct avl_node *** stack_ptr_to_delete = stack_ptr;
		struct avl_node ** nodeplace = &node_to_delete->left;
		
		/* find the right node */
		for (;;) {
			node = *nodeplace;
			if (!node->right)
				break;
			*stack_ptr++ = nodeplace; stack_count++;
			nodeplace = &node->right;
		}
		
		*nodeplace = node->left;/* exchage the rightmost node and it's left child */
		/* use the rightmost node replace the delete node */
		node->left = node_to_delete->left;
		node->right = node_to_delete->right;
		node->height = node_to_delete->height;
		*nodeplace_to_delete = node;
		*stack_ptr_to_delete = &node->left;
	}
	
	if (avl->type == AVL_STR_TYPE)
		zfree(node_to_delete->key);
	ZVAL_DELREF((zval *)node_to_delete->val);/* delete refcout */
	zfree(node_to_delete);
	do_rebalance(stack_ptr, stack_count);
	avl->size--;
	return 0;
}

void *avl_find_min(avl_tree_t *avl) {
	struct avl_node *node;
	
	node = avl->root;
	while (node->left) {
		node = node->left;
	}
	return (node ? node->val : NULL);
}

void *avl_find_max(avl_tree_t *avl) {
	struct avl_node *node;
	
	node = avl->root;
	while (node->right) {
		node = node->right;
	}
	return (node ? node->val : NULL);
}

static void __avl_node_free(avl_tree_t *avl, struct avl_node *node) {
	if (node) {
		__avl_node_free(avl, node->left);
		__avl_node_free(avl, node->right);
		if (avl->type == AVL_STR_TYPE)
			zfree(node->key);
		ZVAL_DELREF((zval *)node->val);/* delete refcount */
		zfree(node);
	}
	return;
}

void avl_destroy(avl_tree_t *avl) {
	__avl_node_free(avl, avl->root);
	zfree(avl);
	return;
}

#if 0
int avl_string_compare(avl_key_t val1, avl_key_t val2) {
	char *str1 = (char *)val1;
	char *str2 = (char *)val2;
	return strcmp((char *)str1, (char *)str2);
}

int main() {
	avl_tree_t *avl;
	char keybuf[256];
	void *vp;
	int i;
	time_t ts, te;
	
	avl = avl_alloc(avl_string_compare);
	ts = time(NULL);
	for (i = 0; i < 1000000; i++) {
		sprintf(keybuf, "Key%d", i);
		vp = strdup(keybuf);
		avl_insert(avl, vp, vp);
	}
	te = time(NULL);
	printf("Insert time-consuming: %d\n", (int)(te - ts));
	printf("Tree size: %d\n", avl->size);
	
	vp = avl_find(avl, "Key100");
	if (vp) {
		printf("Found: %s\n", vp);
	}
	ts = time(NULL);
	printf("Found time-consuming: %d\n", (int)(ts - te));
	
	avl_remove(avl, "Key100");
	te = time(NULL);
	printf("Remove time-consuming: %d\n", (int)(te - ts));
	
	vp = avl_find(avl, "Key100");
	if (vp) {
		printf("Found: %s\n", vp);
	} else {
		printf("Not Found\n");
	}
	ts = time(NULL);
	printf("Found time-consuming: %d\n", (int)(ts - te));
	
	return 0;
}
#endif
