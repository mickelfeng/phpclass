/*
  AVL Tree
  base on <Introduction to algorithm>
  (C) 2011 liexusong <liexusong@qq.com>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef AVLTREE_H
#define AVLTREE_H

#include "php.h"

typedef void *avl_key_t;
typedef int (*avl_compare_t)(avl_key_t, avl_key_t);

typedef struct avl_node avl_node_t;
typedef struct avl_tree avl_tree_t;

#define AVL_STR_TYPE 1
#define AVL_INT_TYPE 2

struct avl_node {
	int height;
	avl_node_t *left;
	avl_node_t *right;
	avl_key_t key;
	void *val;
};

struct avl_tree {
	avl_node_t *root;
	int size;
	int type;
	avl_compare_t compare;
};

#define zmalloc(size) emalloc(size)
#define zfree(val) efree(val)

int avl_default_compare (avl_key_t val1, avl_key_t val2);
avl_tree_t *avl_alloc (avl_compare_t comp, int type);
avl_tree_t *avl_alloc_default ();
void *avl_find (avl_tree_t *avl, avl_key_t key);
int avl_insert (avl_tree_t *avl, avl_key_t key, void *val);
int avl_remove (avl_tree_t *avl, avl_key_t key);
void *avl_find_min (avl_tree_t *avl);
void *avl_find_max (avl_tree_t *avl);
void avl_destroy (avl_tree_t *avl);

#endif
